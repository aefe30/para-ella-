PÁGINA SORPRESA V2 — PARA EMI

1. Abre index.html para probarla.
2. Para personalizarla, abre index.html con VS Code o Bloc de notas.
3. Busca el texto de la carta y sustitúyelo por el tuyo.
4. También puedes cambiar "Erik" por tu firma.

FOTOS:
Esta versión no incluye fotos para que no tengas que compartirlas conmigo.
Si quieres añadirlas, puedo prepararte una versión con una galería de fotos:
- mete tus fotos en una carpeta llamada fotos
- y te preparo el HTML para mostrarlas.

MÚSICA:
Los navegadores suelen bloquear el audio automático. Puedo añadir un botón "Escuchar mientras lees" para que la música empiece al tocarlo.

PUBLICACIÓN:
Puedes subir la carpeta a Cloudflare Pages mediante Drag and drop.
